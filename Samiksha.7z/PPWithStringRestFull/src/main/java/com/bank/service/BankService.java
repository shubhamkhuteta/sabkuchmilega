package com.bank.service;

import java.util.List;
import com.bank.entities.BankEntity;
import com.bank.exception.BankException;

public interface BankService {

	public BankEntity createAccount(BankEntity bank) throws BankException;
	public BankEntity accountsDetails(Long accNo) throws BankException;

}
