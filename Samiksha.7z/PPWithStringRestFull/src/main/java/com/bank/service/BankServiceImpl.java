package com.bank.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bank.dao.BankEntityDao;
import com.bank.entities.BankEntity;
import com.bank.exception.BankException;

@Service
public class BankServiceImpl implements BankService {

	@Autowired
	BankEntityDao bankDao;


	public BankEntity createAccount(BankEntity bank) throws BankException {
			bankDao.save(bank);
			return bankDao.findById(bank.getAccNo()).get();
		}
	

	public BankEntity accountsDetails(Long accNo) throws BankException {
		System.out.println("------3"+accNo);
		if(!bankDao.findById(accNo).isPresent()) {
			System.out.println("------2"+accNo);
			throw new BankException("Sorry, Account No. Not Exist\nPlease Enter a valid Account No.!!");
		}else{
			System.out.println("------3"+accNo);
			BankEntity be =bankDao.findById(accNo).get();
			System.out.println(be);
			return bankDao.findById(accNo).get();
		}
	}

}
