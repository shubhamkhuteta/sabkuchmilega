package com.bank.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.bank.entities.BankEntity;
import com.bank.exception.BankException;
import com.bank.service.BankService;

@RestController
@RequestMapping("/BankApplication")
@CrossOrigin(origins="http://localhost:4200")
public class BankController {
	@Autowired
	BankService bankService;

//	@GetMapping("/ShowOptions")
//	public ResponseEntity<String> ShowOptions() {
//		return new ResponseEntity<String>("Welcome to UnsignedInteger Bank\n\n"+
//				"1. Create Account 		: 	/CreateAccount\n"
//				+ "2. Show Details 		: 	/ShowDetails/{accNo}\n"
//				+ "3. Show Balance		: 	/ShowBalance/{accNo}\n"
//				+ "4. Deposite Amount 	: 	/DepositAmount/{accNo}/{amt}\n"
//				+ "5. Withdraw Amount 	: 	/WithdrawAmount/{accNo}/{amt}\n"
//				+ "6. Fund Transafer 	: 	/FundTransfer/{accNo1}/{amt}/{accNo2}\n"
//				+ "7. Mini Statement 	: 	/MiniStatement/{accNo}", HttpStatus.OK);
//	}
	
	@PostMapping("/CreateAccount")
	public BankEntity createAccount(@RequestBody BankEntity bank) throws BankException {
		return bankService.createAccount(bank);
	}

	@CrossOrigin(origins="http://localhost:4200")
	@GetMapping("/ShowDetails/{accNo}")
	public BankEntity accountsDetails(@PathVariable Long accNo) throws BankException {
		return bankService.accountsDetails(accNo);
	}
}
