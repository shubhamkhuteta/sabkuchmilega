package com.pwd.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pwd.entities.Employee;
import com.pwd.service.EmployeeService;




@RestController
@RequestMapping("/users")
public class UserRestController {

	/** The JPA repository */
    @Autowired
    private EmployeeService employeeService;

	/**
	 * Used to fetch all the users from DB
	 * 
	 * @return list of {@link User}
	 */
    @GetMapping(value = "/all")
    public List<Employee> findAll() {
        return employeeService.findAll();
    }

    /**
	 * Used to find and return a user by name
	 * 
	 * @param name refers to the name of the user
	 * @return {@link User} object
	 */
    @GetMapping(value = "/{name}")
    public Employee findByName(@PathVariable final String employeeName){
        return employeeService.findByName(employeeName);
    }

    /**
	 * Used to create a User in the DB
	 * 
	 * @param users refers to the User needs to be saved
	 * @return the {@link User} created
	 */
    @PostMapping(value = "/load")
    public void load(@RequestBody final Employee employee) {
        employeeService.load(employee);
      // return employeeService.findByEmployeeName(employee.getEmployeeName());
    }
    
    @DeleteMapping(value = "/delete/{id}")
    public void delete(@RequestBody final Employee employee) {
        employeeService.deleteEmployeeById(employee.getEmployeeId());
      // return employeeService.findByEmployeeName(employee.getEmployeeName());
    }
    
    @PutMapping(value = "/update/{email}")
    public void update(@RequestBody final Employee employee) {
    	String empName = employee.getEmployeeName();
    	Employee employee1 = (Employee) employeeService.findByName(empName);
    	employee1.setEmail(employee.getEmail());
        employeeService.updateEmployeeEmailById(employee1);
}
}
//http://localhost:9494/users/load
