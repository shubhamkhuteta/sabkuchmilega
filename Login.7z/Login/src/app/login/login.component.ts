import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../service/authentication.service';
import { User } from '../bean/User';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  accNo = '';
  pwd = '';
  invalidLogin = false;
  user:User;


  constructor(private router: Router,
    private loginservice: AuthenticationService) { 
      this.router=router;
    }

 

  checkLogin(checkData:any) {
    console.log("---------------CD______"+checkData);
    this.user  = new User(checkData.accNo,"",checkData.pwd);
    console.log("---------------CD______"+this.user);
    var u=this.loginservice.loginAccount(this.user);
    u.subscribe((data)=>{
      if(data.accNo==checkData.accNo && data.pwd==checkData.pwd)
      {
       alert("Login successful for id "+data.accNo);}
      else
      {alert("Login denied for id "+checkData.accNo);}
      })
  }

  ngOnInit() {
  }

}