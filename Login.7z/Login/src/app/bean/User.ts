export class User {

    accNo: number;
    name: string;
    pwd: string;

    constructor( userId: number,
        name: string,
        pwd: string)
    {
        this.accNo = userId;
        this.name = name;
        this.pwd = pwd;

    }
}