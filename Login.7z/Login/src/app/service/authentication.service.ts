import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { User } from '../bean/User';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {

  http: HttpClient;
  router:Router;
  user: User;
  constructor(http:HttpClient,router:Router) { 
    this.http=http;
    this.router=router;
  }

  loginAccount(user:User):Observable<any>{
    return this.http.get('http://localhost:5052/BankApplication/ShowDetails/'+user.accNo)
  }

  // fetchUser(accNo:any) {
  //   this.http.get('http://localhost:4200/BankApplication/ShowDetails/'
  //   +accNo).subscribe((data)=>
  //   {
  //     this.convertUser(data);
  //   },(errorC)=>
  //   { 
  //     console.log(errorC.error)
  //     alert(errorC.error.message)

  //   })
  // }

  // convertUser(data:any){
  //     this.user = new User(data.accNo, data.name, data.pwd);
  // }

  // authenticate(accNo, pwd) {
  //   this.fetchUser(accNo);
  //   if (accNo === this.user.accNo && pwd === this.user.pwd) {
  //     sessionStorage.setItem('accNo', accNo)
  //     return true;
  //   } else {
  //     return false;
  //   }
  // }

  isUserLoggedIn() {
    let user = sessionStorage.getItem('accNo')
    console.log(!(user === null))
    return !(user === null)
  }

  logOut() {
    sessionStorage.removeItem('accNo')
  }
}