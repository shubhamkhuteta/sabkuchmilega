import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Transactions } from 'src/app/Models/Transactions';
import { MyServiceService } from 'src/app/Service/my-service.service';
import { Customer } from 'src/app/Models/Customer';

@Component({
  selector: 'app-mini-statement',
  templateUrl: './mini-statement.component.html',
  styleUrls: ['./mini-statement.component.css']
})
export class MiniStatementComponent implements OnInit {

  transactions:Transactions[]=[];
  customers:Customer[]=[];
  service:MyServiceService;


  constructor(service:MyServiceService) { 
    this.service=service;
  }

  miniStatement(data:any){
    this.transactions=this.service.miniStatement(this.service.loginAccount);
  }

  ngOnInit() {
    this.service.fetchTransactions();
    this.customers=this.service.getCustomers();
  }

}
